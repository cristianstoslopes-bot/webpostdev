var de=`
attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`,ue=`
precision highp float;
uniform vec2 uRes;        // css px
uniform float uDpr;
uniform float uOffset;    // em itens
uniform float uCount;
uniform vec2 uItem;       // largura/altura do item (px)
uniform float uGap;
uniform vec2 uLens;       // largura/altura da lente (px)
uniform float uPress;     // 0..1 (lente "aperta" ao arrastar)
uniform vec3 uBg;
uniform sampler2D uAtlas;

float sdRound(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - b + r;
  return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

// amostra a faixa infinita na posi\xE7\xE3o p (px, origem no canto sup. esq.)
vec4 strip(vec2 p) {
  float stride = uItem.x + uGap;
  float x = p.x - uRes.x * 0.5 + uOffset * stride + uItem.x * 0.5;
  float k = floor(x / stride);
  float lx = x - k * stride;
  float ly = p.y - (uRes.y * 0.5 - uItem.y * 0.5);
  float idx = mod(k, uCount);
  vec2 local = vec2(lx, ly) - uItem * 0.5;
  float d = sdRound(local, uItem * 0.5, 18.0);
  float a = 1.0 - smoothstep(-1.0, 1.0, d);
  vec2 uv = clamp(vec2(lx, ly) / uItem, 0.002, 0.998);
  vec3 c = texture2D(uAtlas, vec2((idx + uv.x) / uCount, uv.y)).rgb;
  return vec4(c, a);
}

void main() {
  vec2 p = vec2(gl_FragCoord.x, uRes.y * uDpr - gl_FragCoord.y) / uDpr;
  vec2 c = uRes * 0.5;
  vec2 rel = p - c;
  vec2 hb = uLens * 0.5 * (1.0 - 0.03 * uPress);
  float rad = min(hb.x, hb.y) * 0.22;
  float d = sdRound(rel, hb, rad);          // <0 dentro da lente

  // fora da lente: faixa escurecida
  vec4 s = strip(p);
  vec3 outside = mix(uBg, s.rgb * 0.42 + 0.02, s.a);
  float gray = dot(outside, vec3(0.299, 0.587, 0.114));
  outside = mix(vec3(gray), outside, 0.55);
  // fade nas laterais
  float edge = smoothstep(0.0, uRes.x * 0.16, p.x) * smoothstep(0.0, uRes.x * 0.16, uRes.x - p.x);
  outside = mix(uBg, outside, edge);

  // dentro da lente: refra\xE7\xE3o + dispers\xE3o crom\xE1tica na borda
  float rim = 42.0;
  float e = clamp(-d / rim, 0.0, 1.0);          // 0 na borda, 1 no miolo
  float bend = pow(1.0 - e, 2.2);
  vec2 dir = rel / max(hb, vec2(1.0));
  float mag = 1.045 + 0.02 * uPress;
  vec2 base = c + rel / mag;
  float k = 34.0 * bend;
  vec4 sr = strip(base - dir * k * 1.18);
  vec4 sg = strip(base - dir * k);
  vec4 sb = strip(base - dir * k * 0.82);
  vec3 glass = vec3(
    mix(uBg.r, sr.r, sr.a),
    mix(uBg.g, sg.g, sg.a),
    mix(uBg.b, sb.b, sb.a));
  // tom levemente azulado + brilho especular na borda
  glass = glass * 1.04 + vec3(0.0, 0.015, 0.04) * bend;
  vec2 nd = normalize(rel + 0.0001);
  float spec = pow(clamp(dot(nd, normalize(vec2(-0.55, -0.8))), 0.0, 1.0), 6.0);
  float rimLine = smoothstep(4.0, 0.0, abs(d + 1.5));
  glass += vec3(1.0) * spec * smoothstep(14.0, 0.0, -d) * 0.55;
  glass += vec3(0.3, 0.6, 1.0) * rimLine * 0.55;

  float inside = 1.0 - smoothstep(-1.0, 1.0, d);
  // sombra/halo azul ao redor da lente
  float halo = exp(-max(d, 0.0) / 26.0) * (1.0 - inside) * 0.35;
  vec3 col = mix(outside, glass, inside) + vec3(0.1, 0.4, 1.0) * halo * 0.6;
  gl_FragColor = vec4(col, 1.0);
}`;function ce(n){return new Promise((f,s)=>{let e=new Image;e.decoding="async",e.onload=()=>f(e),e.onerror=s,e.src=n})}async function me(n,f,s={}){var J,Q,$,ee;let e=n.getContext("webgl",{antialias:!1,alpha:!1,premultipliedAlpha:!1});if(!e)throw new Error("WebGL indispon\xEDvel");let re=($=(Q=s.reducedMotion)!=null?Q:(J=window.matchMedia)==null?void 0:J.call(window,"(prefers-reduced-motion: reduce)").matches)!=null?$:!1,y=(ee=s.background)!=null?ee:[0,0,0],k=(t,a)=>{let o=e.createShader(t);if(e.shaderSource(o,a),e.compileShader(o),!e.getShaderParameter(o,e.COMPILE_STATUS))throw new Error(e.getShaderInfoLog(o)||"shader");return o},m=e.createProgram();if(e.attachShader(m,k(e.VERTEX_SHADER,de)),e.attachShader(m,k(e.FRAGMENT_SHADER,ue)),e.linkProgram(m),!e.getProgramParameter(m,e.LINK_STATUS))throw new Error(e.getProgramInfoLog(m)||"link");e.useProgram(m);let F=e.createBuffer();e.bindBuffer(e.ARRAY_BUFFER,F),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),e.STATIC_DRAW);let O=e.getAttribLocation(m,"aPos");e.enableVertexAttribArray(O),e.vertexAttribPointer(O,2,e.FLOAT,!1,0,0);let l=t=>e.getUniformLocation(m,t),d={res:l("uRes"),dpr:l("uDpr"),offset:l("uOffset"),count:l("uCount"),item:l("uItem"),gap:l("uGap"),lens:l("uLens"),press:l("uPress"),bg:l("uBg"),atlas:l("uAtlas")},oe=await Promise.all(f.map(t=>ce(t.src))),ne=Math.min(e.getParameter(e.MAX_TEXTURE_SIZE),8192),E=Math.min(1e3,Math.floor(ne/f.length)),G=Math.round(E/1.6),R=document.createElement("canvas");R.width=E*f.length,R.height=G;let ae=R.getContext("2d");oe.forEach((t,a)=>{let o=Math.max(E/t.width,G/t.height),i=t.width*o,w=t.height*o;ae.drawImage(t,a*E+(E-i)/2,(G-w)/2*0,i,w)});let H=e.createTexture();e.bindTexture(e.TEXTURE_2D,H),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,e.RGBA,e.UNSIGNED_BYTE,R),e.uniform1i(d.atlas,0),e.uniform1f(d.count,f.length),e.uniform3f(d.bg,y[0],y[1],y[2]);let x=0,v=0,M=1,u=0,g=0,C=0;function N(){let t=n.getBoundingClientRect();x=t.width,v=t.height,M=Math.min(window.devicePixelRatio||1,2),n.width=Math.round(x*M),n.height=Math.round(v*M),e.viewport(0,0,n.width,n.height),g=v*.74,u=g*1.6,u>x*.78&&(u=x*.78,g=u/1.6),C=Math.max(16,u*.07),e.uniform2f(d.res,x,v),e.uniform1f(d.dpr,M),e.uniform2f(d.item,u,g),e.uniform1f(d.gap,C),e.uniform2f(d.lens,u*1.04,g*1.06),c()}let h=0,r=0,P=0,A=0,L=0,W=0,p=f.length,_=t=>(t%p+p)%p;function c(){L||(L=requestAnimationFrame(ie))}function ie(){var o;L=0;let t=re?1:.14;h+=(r-h)*t,P+=(A-P)*.2,Math.abs(r-h)<5e-4&&(h=r),e.uniform1f(d.offset,h),e.uniform1f(d.press,P),e.drawArrays(e.TRIANGLE_STRIP,0,4);let a=_(Math.round(h));a!==W&&(W=a,(o=s.onChange)==null||o.call(s,a)),(h!==r||Math.abs(P-A)>.002)&&c()}let q=new ResizeObserver(N);q.observe(n),N();let I=!1,Y=0,z=0,U=0,S=0,B=0,T=0,b=()=>u+C;function V(t){I=!0,T=0,Y=U=t.clientX,z=r,S=performance.now(),B=0,A=1,c()}function K(t){var i;if(!I)return;let a=t.clientX-Y;T=Math.max(T,Math.abs(a)),T>6&&((i=n.setPointerCapture)==null||i.call(n,t.pointerId));let o=performance.now();B=(t.clientX-U)/Math.max(1,o-S),U=t.clientX,S=o,r=z-a/b(),c()}function D(t){var a;if(I){if(I=!1,A=0,T<=6){let o=n.getBoundingClientRect(),i=t.clientX-o.left,w=t.clientY-o.top,te=i-x/2+r*b()+u/2,X=Math.floor(te/b()),se=te-X*b(),le=w>v/2-g/2&&w<v/2+g/2;se<=u&&le&&(X===Math.round(r)?(a=s.onOpen)==null||a.call(s,_(X)):r=X)}else r=Math.round(r-B*4/Math.max(.6,b()/400));c()}}let Z;function j(t){Math.abs(t.deltaX)<=Math.abs(t.deltaY)||(t.preventDefault(),r+=t.deltaX/b(),c(),clearTimeout(Z),Z=window.setTimeout(()=>{r=Math.round(r),c()},140))}return n.addEventListener("pointerdown",V),window.addEventListener("pointermove",K),window.addEventListener("pointerup",D),window.addEventListener("pointercancel",D),n.addEventListener("wheel",j,{passive:!1}),{next:()=>{r=Math.round(r)+1,c()},prev:()=>{r=Math.round(r)-1,c()},goTo:t=>{let a=Math.round(r),o=_(a),i=t-o;i>p/2&&(i-=p),i<-p/2&&(i+=p),r=a+i,c()},index:()=>_(Math.round(r)),dispose(){cancelAnimationFrame(L),q.disconnect(),n.removeEventListener("pointerdown",V),window.removeEventListener("pointermove",K),window.removeEventListener("pointerup",D),window.removeEventListener("pointercancel",D),n.removeEventListener("wheel",j),e.deleteTexture(H),e.deleteBuffer(F),e.deleteProgram(m)}}}export{me as createLiquidGlass};
